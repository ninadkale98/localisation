//
// Created by robot on 11/21/22.
//

#include "motor_driver.h"

MotorDriver::MotorDriver() {
    std::string servo_topic, rpm_topic, estop_topic, drive_controller_topic;

    node_handle.getParam("car_wheel_radius", this->wheel_radius);
    node_handle.getParam("car_gear_ratio", this->gear_ratio);
    node_handle.getParam("tire_circumference", this->tire_circumference);
    node_handle.getParam("max_servo_pos_in_radians", this->max_servo_pos_rad);

    node_handle.getParam("set_servo_topic", servo_topic);
    node_handle.getParam("set_rpm_topic", rpm_topic);

    this->servo_pub = node_handle.advertise<std_msgs::Float64>(servo_topic, 1);
    this->rpm_pub = node_handle.advertise<std_msgs::Float64>(rpm_topic, 1);

    node_handle.getParam("estop_topic", estop_topic);
    node_handle.getParam("drive_controller_topic", drive_controller_topic);

    this->estop_sub = node_handle.subscribe(estop_topic, 1, &MotorDriver::e_stop_callback, this);
    this->drive_sub = node_handle.subscribe(drive_controller_topic, 1, &MotorDriver::drive_callback, this);
}

void MotorDriver::drive_callback(ackermann_msgs::AckermannDriveStamped msg) {
    while (this->e_stop) {
        this->publish_rpm_and_servo(0, 0);
    }
    float speed = msg.drive.speed;
    float steer = msg.drive.steering_angle;
    this->publish_rpm_and_servo(speed, steer);
    return;
}

void MotorDriver::e_stop_callback(std_msgs::Bool msg) {
    this->e_stop = msg.data;
    return;
}

void MotorDriver::publish_rpm_and_servo(float speed, float steer) {
    std_msgs::Float64 rpm_msg = std_msgs::Float64();
    rpm_msg.data = this->speed_to_RPM(speed);
    std_msgs::Float64 servo_msg = std_msgs::Float64();
    float servo = this->steer_to_servo(steer);
    servo_msg.data = std::min(std::max(float(0), servo), float(1));

    this->rpm_pub.publish(rpm_msg);
    this->servo_pub.publish(servo_msg);
    return;
}

float MotorDriver::speed_to_RPM(float speed) {
    float wheelRPM = (speed / tire_circumference) * 60;
    return wheelRPM * gear_ratio;
}

float MotorDriver::speed_to_duty_cycle(float speed) {
    // TODO convert to duty cycle
    float wheelRPM = (speed / tire_circumference) * 60;
    float motorRPM = wheelRPM * gear_ratio;
    return 0;
}

float MotorDriver::steer_to_servo(float steer) {
    return (steer / max_servo_pos_rad) * 0.5 + 0.5;

}

float MotorDriver::servo_to_steer(float servo) {
    return (servo - 0.5) * 2 * max_servo_pos_rad;
}

int main() {
    ros::Rate loop_rate(10);
    MotorDriver motor = MotorDriver();

    ros::spin();
}