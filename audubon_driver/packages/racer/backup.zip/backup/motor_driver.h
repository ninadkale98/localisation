//
// Created by robot on 11/21/22.
//

#ifndef AUDUBON_TRANSITORY_MOTOR_DRIVER_H
#define AUDUBON_TRANSITORY_MOTOR_DRIVER_H

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Float64.h"
#include "ackermann_msgs/AckermannDriveStamped.h"
#include "cmath"


class MotorDriver {
public:
    MotorDriver();

    ros::NodeHandle node_handle;
private:
    bool e_stop = false;
    float wheel_radius, gear_ratio, tire_circumference, max_servo_pos_rad;
    ros::Publisher servo_pub, rpm_pub;
    ros::Subscriber estop_sub, drive_sub;

    void drive_callback(ackermann_msgs::AckermannDriveStamped msg);

    void e_stop_callback(std_msgs::Bool msg);

    void publish_rpm_and_servo(float speed, float steer);

    float speed_to_RPM(float speed);

    float speed_to_duty_cycle(float speed);

    float servo_to_steer(float servo);

    float steer_to_servo(float steer);
};


int main();

#endif //AUDUBON_TRANSITORY_MOTOR_DRIVER_H
