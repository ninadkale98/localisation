//
// Created by robot on 11/29/22.
//

#ifndef AUDUBON_TRANSITORY_POWER_ACCUMULATOR_H
#define AUDUBON_TRANSITORY_POWER_ACCUMULATOR_H

#include "ros/ros.h"
#include "cmath"
#include "std_msgs/String.h"
#include "std_msgs/Bool.h"
#include "std_msgs/Float64.h"
#include "ackermann_msgs/AckermannDriveStamped.h"
#include "ctime"


class power_accumulator {

};


#endif //AUDUBON_TRANSITORY_POWER_ACCUMULATOR_H
