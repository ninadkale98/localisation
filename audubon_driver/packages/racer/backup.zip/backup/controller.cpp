//
// Created by robot on 11/8/22.
//

#include "controller.h"

float MAX_SERVO_POS_RAD;


PID::PID(float k_p, float k_d, float k_i) {
    kp = k_p;
    kd = k_d;
    ki = k_i;
    prev_err = 0;
    prev_err_time = ros::Time::now();
    err_sum = 0;
};

Controller::Controller() {
    float kp_speed, kp_steer, ki_speed, ki_steer, kd_speed, kd_steer;
    ros::NodeHandle handle;
    std::string odom_topic, drive_topic, drive_controlled_topic, servo_topic;

    handle.getParam("max_servo_pos_in_radians", MAX_SERVO_POS_RAD);


    handle.getParam("odom_topic", odom_topic);
    odom_sub = handle.subscribe(odom_topic, 1, &Controller::odom_callback, this);

    handle.getParam("drive_topic", drive_topic);
    drive_sub = handle.subscribe(drive_topic, 1, &Controller::drive_callback, this);

    handle.getParam("get_servo_topic", servo_topic);
    servo_sub = handle.subscribe(servo_topic, 1, &Controller::servo_pos_callback, this);

    handle.getParam("drive_controlled_topic", drive_controlled_topic);
    drive_pub = handle.advertise<ackermann_msgs::AckermannDriveStamped>(drive_controlled_topic, 1);

    handle.getParam("kp_speed", kp_speed);
    handle.getParam("kp_steer", kp_steer);
    handle.getParam("ki_speed", ki_speed);
    handle.getParam("ki_steer", ki_steer);
    handle.getParam("kd_speed", kd_speed);
    handle.getParam("kd_steer", kd_steer);

    speed_PID_ptr = std::make_unique<PID>(kp_speed, ki_speed, kd_speed);
    steer_PID_ptr = std::make_unique<PID>(kp_steer, ki_steer, kd_steer);
};


void Controller::drive_callback(ackermann_msgs::AckermannDriveStamped msg) {
    float desired_speed, desired_steer, controlled_speed, controlled_steer;
    desired_speed = msg.drive.speed;
    desired_steer = msg.drive.steering_angle;

    controlled_speed = this->speed_PID_ptr->compute(this->current_speed, desired_speed);
    controlled_steer = this->steer_PID_ptr->compute(this->current_steer, desired_steer);
    this->drive_publish(controlled_speed, controlled_steer);
    return;
}

void Controller::drive_publish(float speed, float steer) {
    ackermann_msgs::AckermannDriveStamped msg;
    msg = ackermann_msgs::AckermannDriveStamped();
    msg.drive.speed = speed;
    msg.drive.steering_angle = steer;
    this->drive_pub.publish(msg);
    return;
}

void Controller::odom_callback(nav_msgs::Odometry msg) {
    float velocity, heading;
    velocity = msg.twist.twist.linear.x;
    heading = msg.pose.pose.orientation.z;

    this->current_speed = velocity;

    // TODO converting from heading to steering angle and testing that
    return;
}

void Controller::servo_pos_callback(std_msgs::Float64 msg) {
    this->current_servo_pos = msg.data;
    this->current_steer = servo_to_steer(msg.data);
    // TODO servo to steer
    return;
}

float PID::compute(float current, float desired) {
    ros::Time now = ros::Time::now();
    double time_diff = now.toSec() - this->prev_err_time.toSec();
    this->prev_err_time = now;
    double err = desired - current;
    double err_diff = err - this->prev_err;
    this->prev_err = err;
    this->err_sum += err;

    double p = this->kp * err;
    double i = this->err_sum * this->ki;
    double d;
    if (time_diff == 0) {
        d = 0;
    } else {
        d = this->kd * err_diff / time_diff;
    }
    return (p + i + d);
}

float servo_to_steer(float servo) {
    return (servo - 0.5) * 2 * MAX_SERVO_POS_RAD;
}

// TODO make 
int main(int argc, char const *argv[])
{

    ros::init(argc, argv, "controller");
    Controller c = Controller();
    ros::spin();
   
    return 0;
}
