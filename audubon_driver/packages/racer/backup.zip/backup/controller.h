//
// Created by robot on 11/8/22.
//

#ifndef RACER_CONTROLLER_H
#define RACER_CONTROLLER_H

#include "ros/ros.h"
#include "ackermann_msgs/AckermannDriveStamped.h"
#include "nav_msgs/Odometry.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Bool.h"
#include "std_msgs/String.h"

class PID {
private:
    float kp, kd, ki, prev_err, err_sum;
    ros::Time prev_err_time;

public:
    PID(float k_p, float k_d, float k_i);

    float compute(float current, float desired);
};

class Controller {
private:
    ros::Subscriber odom_sub, drive_sub, servo_sub;
    ros::Publisher drive_pub;

    float current_speed;
    float current_servo_pos;
    float current_steer;

    std::unique_ptr<PID> speed_PID_ptr;
    std::unique_ptr<PID> steer_PID_ptr;

public:
    Controller();

    void drive_callback(ackermann_msgs::AckermannDriveStamped msg);

    void drive_publish(float speed, float steer);

    void odom_callback(nav_msgs::Odometry msg);

    void servo_pos_callback(std_msgs::Float64 msg);
};

float servo_to_steer(float servo);

#endif //RACER_CONTROLLER_H
