#!/usr/bin/env python3

# Imports
import rospy
import math
from std_msgs.msg import String, Bool, Float64
from ackermann_msgs.msg import AckermannDriveStamped
from nav_msgs.msg import Odometry

class Controller:

    def __init__(self) -> None:
        self.odom_sub = rospy.Subscriber(rospy.get_param("odom_topic"),Odometry, self.odom_callback, queue_size=1)
        self.drive_sub = rospy.Subscriber(rospy.get_param("drive_topic"),AckermannDriveStamped, self.drive_callback, queue_size=1)
        self.drive_pub  = rospy.Publisher(rospy.get_param("drive_controlled_topic"), AckermannDriveStamped, queue_size=1)
        self.servo_pos_sub = rospy.Subscriber(rospy.get_param("get_servo_topic"),Float64, self.servo_pos_callback, queue_size=1)
        self.current_speed = 0
        self.current_servo_pos = 0.5
        self.current_steer = 0

        self.speed_pid = PID(0.6, 0.05, 0.001)
        self.steer_pid = PID(0.6, 0.05, 0.001)
    
    # get desired speed and steer , perform PID and publish desired speed and steer
    def drive_callback(self, msg):
        desired_speed = msg.drive.speed
        desired_steer = msg.drive.steering_angle

        controlled_speed = self.speed_pid.compute(self.current_speed, desired_speed)
        controlled_steer = self.steer_pid.compute(self.current_steer, desired_steer)

        self.drive_publish(controlled_speed, controlled_steer)
        return

    # publish controlled speed and steering angle
    def drive_publish(self, speed, steer):
        m  = AckermannDriveStamped()
        m.drive.speed = speed
        m.drive.steering_angle = steer
        self.drive_pub.publish(m)
        return

    # set current speed
    def odom_callback(self, msg):
        sp = msg.twist.twist.linear
        self.current_speed = math.sqrt(sp.x*sp.x+sp.y*sp.y)
        return
    

    #set current steer, servo pos
    def servo_pos_callback(self,msg):
        self.current_servo_pos = msg.data
        self.current_steer = servo_to_steer(msg.data)
        return

# PID controller
class PID:
    def __init__(self, kp, kd,ki) -> None:
        self.kp = kp
        self.kd = kd
        self.ki = ki
        self.prev_err = 0
        self.prev_err_time = rospy.Time()
        self.err_sum = 0

    #  computes controlled value using PID
    def compute(self, current, desired):
        now = rospy.Time()
        time_diff = now.to_sec() - self.prev_err_time.to_sec()
        self.prev_err_time = now
        err = desired - current
        err_diff = err - self.prev_err
        self.prev_err = err
        self.err_sum += err

        p = self.kp*err
        d = self.kd*err_diff/time_diff
        i = self.err_sum*self.ki
        return current + p+i+d


#TODO: get exact value
max_servo_pos_in_radians = rospy.get_param("max_servo_pos_in_radians")

def steer_to_servo(steer):
    # (steer / ( max servo position in radians) )*0.5 (conver mapping -1 to 1 into -0.5 to 0.5) + 0.5 (-0.5 to 0.5 into 0 to 1)
    return (steer/max_servo_pos_in_radians)*0.5 + 0.5

def servo_to_steer(servo):
    return (servo - 0.5) * 2 * max_servo_pos_in_radians

if __name__ == "__main__":
    rospy.init_node("Controller",  anonymous=True)
    c = Controller()
    rospy.spin()